# 研究输入与自动报告

采集由当前 AI 助手使用真实可用的搜索、受控浏览器或用户导出完成；语义拆解、选题与写稿由 AI 完成。脚本负责数据校验、统计与稳定输出，不自行登录、不调用模型 API、不假装爬取平台。

## 文件契约

账号配置从 [研究配置模板](../assets/研究配置模板.json) 复制为用户工作区 `研究配置.json`。复用用户已给的信息：行业、平台、观众、账号目标、人设、本人案例、对标账号、关键词、时间范围和样本上限。只询问影响本次研究的缺项；案例不清楚时不编造经历。

`视频研究输入.json` 顶层为 `posts`。每条必须有 `source`、`title`，可选：

- `video_id`、`platform`、`account`、`account_url`、`published_at`、`captured_at`、`duration_seconds`。
- `description`（发布描述）、`transcript` 或 `transcript_file`（实际全文/片段）、`content_scope`（全文/片段/标题描述）、`snapshot_file`、`evidence_status`、`notes`。
- `views`、`likes`、`comments`、`saves`、`shares`：精确非负整数或 null。`metrics_raw` 保存“2.8万”等页面原文；缩略计数不转成精确整数，也不猜该数字是什么指标。
- `comment_samples`：列表，每条含 `text`、`source`，可加 `category`、`captured_at`。不保存评论者私人资料；同作品评论无独立链接时用作品链接并在备注说明定位方式。

先运行 `organize_research.py` 得到资料库，再读取原件和资料库写 `分析输入.json`。视频标注和候选都用资料库中的精确 source，不能引用没采集的来源。结构：

```json
{
  "videos": [{
    "source": "从资料库复制来源",
    "content_scope": "全文",
    "content_evidence": "实际转写文件或观察到的段落与时间",
    "topics": ["高频主题"],
    "hook_type": "痛点提问",
    "hook": "观察到的开头",
    "structure": ["问题", "方法", "证据", "结果"],
    "visual_mix": "人物、真实素材、证据与动画如何分工",
    "observation": "实际观察",
    "inference": "基于观察的推断",
    "reuse": "我方可复用结构"
  }],
  "accounts": [{
    "account": "账号名",
    "source_refs": ["从资料库复制来源"],
    "audience": "服务人群推断",
    "themes": ["主题"],
    "performance": "基于可见指标的观察及样本限制",
    "comment_findings": "重复问题与实际样本数量；未读则明确未读",
    "business_model": "据可见广告或产品推断；无依据留空",
    "opportunities": "内容空白与我方适配条件"
  }],
  "candidates": [{
    "id": "topic-01", "priority": 1,
    "title": "具体需求与成果", "audience": "观众",
    "source_refs": ["从资料库复制来源"],
    "reason": "推荐理由", "opening": "适合我方的开头",
    "fit": "与人设和真实案例的关系",
    "heat_basis": "实际可见指标或近期多来源信号；未知留空",
    "discussion_basis": "实际评论需求；未知留空",
    "evidence_plan": ["可获取或已有的证据"],
    "risks": ["前提、成本或未核实能力"]
  }],
  "draft": {
    "candidate_id": "topic-01",
    "source_refs": ["从资料库复制来源"],
    "text": "完整可复制原创正文，含总结和结尾"
  }
}
```

结构是字段示例，不能把示例文字直接当事实。没有全文时标 `标题/描述`，不分析未读的整片。用户只要资料表可省略分析；只要选题不创建 draft。用户选题后再产出对应初稿；如用户授权先准备稿，明确尚需确认，不擅自进入收费生成。

## 执行与输出

```text
python <技能目录>/scripts/organize_research.py 视频研究输入.json --output 资料整理
python <技能目录>/scripts/research_report.py 资料整理/视频资料库.json --config 研究配置.json --analysis 分析输入.json --output 研究交付_v1
```

报告目录已存在时拒绝覆盖，改用新版本。省略 `--analysis` 仅输出统计及明确的空分析提示，不制造推荐。输出：视频资料表和 JSON 库、账号样本统计、高表现候选、评论问题、对标账号报告、内容结构报告、候选选题表/Markdown、配置与分析原件、整理记录；有 draft 时另写纯文本初稿。

`高表现候选.csv` 按平台、账号和指标分别排序，保留同账号样本中位数和可比数量；不是算法评分或“爆款已验证”。AI 还需核对相近发布时间、片长、题材以及原始计数来源。跨平台和不同指标不可当同一排行榜。热度、讨论、适配都附证据或理由，不编假分。

验收：来源可追溯；重复记录不吞补充字段；未知指标仍为 null；精确零保留；不同平台账号不混合；只读标题不声称看过全文；不存在的来源被拒绝；初稿不冒用他人经历和成绩。脚本成功不等于采集和语义判断全部正确。
