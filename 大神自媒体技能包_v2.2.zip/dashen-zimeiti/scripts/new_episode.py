"""Create a fresh episode scaffold; refuse to overwrite existing work."""
import argparse
import csv
import json
import shutil
from pathlib import Path

def create(output, title):
    output=Path(output).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=False)
    for name in ['研究','文案','配音','数字人','素材','证据','动画','工程','封面','导出','验收']:
        (output/name).mkdir()
    config_template = Path(__file__).resolve().parents[1] / 'assets' / '研究配置模板.json'
    # A copied standalone helper may not include the asset; retain a usable fallback.
    if config_template.is_file():
        shutil.copyfile(config_template, output/'研究'/'研究配置.json')
    else:
        (output/'研究'/'研究配置.json').write_text(json.dumps({
            'industry':'','audience':'','platforms':[],'persona':'','own_cases':[],
            'benchmark_accounts':[],'keywords':[],'period_start':None,'period_end':None,
            'sample_limit':15,'selected_topic':None},ensure_ascii=False,indent=2),encoding='utf-8')
    config={
        '模板版本':'2.2','题目':title,'受众':'','本期对标':[],
        '文案版本':'','最终音轨':'','认可人物素材':'','画幅':'16:9',
        '分辨率':[1920,1080],'帧率':30,'实际时长秒':None,
        '章节':[],'封面标题':'','封面比例':['3:4','4:3'],
        '画面风格':'先读取 Skill 的 local-profile.md、result-first-video-standard.md 与 production-template.md',
        '开头成果与对应口播':'','人物出现与小窗策略':'','各段结果验收条件':[],
        '交付目录':str(output/'导出'),'平台采集状态':'未验证',
    }
    (output/'本期配置.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    tables={
        '镜头表.csv':['起始秒','结束秒','口播原句','句意','主视觉类型','素材路径','来源类别','焦点','动画','转场','音效','字幕避让'],
        '素材索引.csv':['文件','来源','采集日期','支撑说法','类别','使用位置','验证状态'],
        '验收清单.csv':['项目','状态','证据文件','备注'],
    }
    for name,header in tables.items():
        with (output/name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(header)
            if name=='验收清单.csv':
                for item in ['完整对白','声音读音与切点','人物身份与口型','素材对应句意','证据来源与边界','动画表达变化','字幕同步与可读性','开头中间尾帧','全片解码','输出规格与音轨','封面3比4','封面4比3']:
                    writer.writerow([item,'未检查','',''])
    (output/'制作状态.md').write_text(f'# {title}\n\n模板：大神自媒体 v2.1\n\n## 当前阶段\n待填入本期资料。\n\n## 固定标准\n读取 references/production-template.md；本机存在 local-profile.md 时读取最新认可结果。按本期句意组合人物、素材、证据与动画，不照搬旧时长、事实或资产 ID。\n\n## 输入与产物\n见本期配置.json、镜头表.csv、素材索引.csv。\n\n## 验收\n见验收清单.csv；默认未检查，禁止预填通过。\n',encoding='utf-8')
    return output

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    parser.add_argument('--title',required=True)
    args=parser.parse_args()
    try:
        print(create(args.output,args.title))
    except FileExistsError:
        parser.exit(2,'目标目录已经存在，未覆盖任何文件。\n')
