"""Build traceable reports from observed posts and AI analysis. No network/API calls."""
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from statistics import median

from organize_research import normalize, COUNTS


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def text(value):
    if value is None or value == '':
        return '未采集'
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def cell(value):
    return text(value).replace('|', '\\|').replace('\n', '<br>')


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(cell(v) for v in row) + ' |' for row in rows])


def csv_write(path, fields, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows({field: text(row.get(field)) if isinstance(row.get(field), (list, dict))
                         else row.get(field) for field in fields} for row in rows)


def validate_analysis(analysis, sources, scopes=None):
    if not isinstance(analysis, dict):
        raise ValueError('Analysis must be an object')
    for field in ['videos', 'accounts', 'candidates']:
        if not isinstance(analysis.get(field, []), list):
            raise ValueError(f'{field} must be a list')
    annotated = set()
    for video in analysis.get('videos', []):
        if not isinstance(video, dict):
            raise ValueError('Video annotation must be an object')
        if video.get('source') not in sources or video['source'] in annotated:
            raise ValueError('Video annotation needs a unique collected source')
        annotated.add(video['source'])
        if video.get('hook') and not video.get('content_evidence'):
            raise ValueError('A hook analysis needs content_evidence and content_scope')
        if video.get('hook') and video.get('content_scope') not in ['全文', '片段', '标题/描述']:
            raise ValueError('Invalid annotation content_scope')
        if scopes and video.get('content_scope') == '全文' and scopes.get(video['source']) != '全文':
            raise ValueError('Full-content analysis requires a full-content source')
        if not isinstance(video.get('topics', []), list):
            raise ValueError('topics must be a list')
    for item in analysis.get('accounts', []) + analysis.get('candidates', []):
        if not isinstance(item, dict):
            raise ValueError('Account/candidate annotation must be an object')
        refs = item.get('source_refs')
        if not isinstance(refs, list) or not refs or not set(refs).issubset(sources):
            raise ValueError('Account/candidate source_refs must refer to collected posts')
    ids = []
    required = ['id', 'title', 'audience', 'reason', 'opening', 'fit', 'risks', 'evidence_plan', 'priority']
    for candidate in analysis.get('candidates', []):
        if any(key not in candidate for key in required):
            raise ValueError('Candidate is missing required fields')
        ids.append(candidate['id'])
        if type(candidate['priority']) is not int or candidate['priority'] < 1:
            raise ValueError('priority must be a positive integer; 1 means recommended first')
    if len(set(ids)) != len(ids):
        raise ValueError('Candidate ids must be unique')
    draft = analysis.get('draft')
    if draft:
        if draft.get('candidate_id') not in ids or not draft.get('text'):
            raise ValueError('Draft needs an existing candidate_id and text')
        if not isinstance(draft.get('source_refs'), list) or not draft['source_refs'] or not set(draft['source_refs']).issubset(sources):
            raise ValueError('Draft source_refs must refer to collected posts')


def build(data, config, analysis, output):
    if not isinstance(data, dict) or not isinstance(data.get('posts'), list):
        raise ValueError('Input must contain posts')
    posts, duplicates = normalize(data['posts'])
    sources = {post['source'] for post in posts}
    validate_analysis(analysis, sources, {p['source']: p.get('content_scope') for p in posts})
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError('Output directory exists; choose a new review version')
    output.mkdir(parents=True)
    csv_write(output / '视频资料表.csv', list(posts[0]) if posts else ['source', 'title'], posts)
    (output / '视频资料库.json').write_text(json.dumps({'posts': posts}, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / '研究配置.json').write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / '分析输入.json').write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding='utf-8')
    annotations = {v['source']: v for v in analysis.get('videos', [])}
    groups = defaultdict(list)
    for post in posts:
        # Platform is part of account identity. Unknown authors remain separate.
        key = (post.get('platform'), post.get('account_url') or post.get('account') or post['source'])
        groups[key].append(post)
    account_stats, performance = [], []
    for (platform, identity), batch in groups.items():
        stats = {'platform': platform, 'account': batch[0].get('account') or identity, 'sample_count': len(batch)}
        for metric in COUNTS:
            known = [post[metric] for post in batch if post[metric] is not None]
            stats[metric + '_known'] = len(known)
            stats[metric + '_median'] = median(known) if known else None
            for post in batch:
                if post[metric] is not None:
                    performance.append({'source': post['source'], 'platform': platform, 'account': stats['account'],
                                        'metric': metric, 'value': post[metric],
                                        'sample_median': stats[metric + '_median'],
                                        'comparable_samples': len(known),
                                        'label': '可见指标样本；未判定爆款'})
        account_stats.append(stats)
    csv_write(output / '账号样本统计.csv', ['platform', 'account', 'sample_count'] +
              [f'{m}_{suffix}' for m in COUNTS for suffix in ['known', 'median']], account_stats)
    csv_write(output / '高表现候选.csv', ['source', 'platform', 'account', 'metric', 'value', 'sample_median',
              'comparable_samples', 'label'], sorted(performance, key=lambda v: (v['platform'] or '', v['account'], v['metric'], -v['value'])))
    topics, hooks = Counter(), Counter()
    for value in annotations.values():
        topics.update(set(value.get('topics', [])))
        if value.get('hook_type'):
            hooks[value['hook_type']] += 1
    comments = []
    for post in posts:
        for comment in post.get('comment_samples') or []:
            comments.append({'video_source': post['source'], 'source': comment['source'],
                             'text': comment['text'], 'category': comment.get('category'),
                             'captured_at': comment.get('captured_at') or post.get('captured_at')})
    csv_write(output / '评论问题.csv', ['video_source', 'source', 'text', 'category', 'captured_at'], comments)
    common = ['# 内容结构报告', '', f'已整理 {len(posts)} 条作品，实际标注 {len(annotations)} 条。',
              '按全文、片段、标题/描述区分；标题分析不能证明口播开头和整片结构。', '',
              '## 高频主题', table(['主题', '标注作品数'], topics.most_common()), '',
              '## 钩子类型', table(['类型', '标注作品数'], hooks.most_common())]
    for post in posts:
        v = annotations.get(post['source'])
        if not v:
            continue
        common += ['', f'## {post["title"]}', f'来源：{post["source"]}',
                   f'读取范围：{text(v.get("content_scope"))}；依据：{text(v.get("content_evidence"))}',
                   f'观察：{text(v.get("observation"))}', f'开头：{text(v.get("hook"))}',
                   f'信息顺序：{text(v.get("structure"))}', f'证据与画面：{text(v.get("visual_mix"))}',
                   f'推断：{text(v.get("inference"))}', f'可复用方法：{text(v.get("reuse"))}']
    (output / '内容结构报告.md').write_text('\n'.join(common) + '\n', encoding='utf-8')
    report = ['# 对标账号报告', '', f'研究范围：{text(config.get("industry"))}；目标观众：{text(config.get("audience"))}',
              f'采样 {len(posts)} 条，{len(groups)} 个账号/未知作者组，读取 {len(comments)} 条评论。',
              '统计只覆盖本次样本；不代表行业热度、推荐机制或完整账号。', '',
              table(['账号', '平台', '样本', '已知播放数', '已知点赞数'],
                    [[s['account'], s['platform'], s['sample_count'], s['views_known'], s['likes_known']] for s in account_stats])]
    for a in analysis.get('accounts', []):
        report += ['', f'## {text(a.get("account"))}', f'服务人群（推断）：{text(a.get("audience"))}',
                   f'主要主题：{text(a.get("themes"))}', f'表现观察：{text(a.get("performance"))}',
                   f'观众问题：{text(a.get("comment_findings"))}', f'商业模式（推断）：{text(a.get("business_model"))}',
                   f'适配与空白：{text(a.get("opportunities"))}', f'来源：{text(a["source_refs"])}']
    if not analysis.get('accounts'):
        report += ['', '尚无账号语义分析；上表仅为可见样本统计。']
    (output / '对标账号报告.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
    candidates = sorted(analysis.get('candidates', []), key=lambda c: c['priority'])
    fields = ['id', 'priority', 'title', 'audience', 'source_refs', 'reason', 'opening', 'fit',
              'heat_basis', 'discussion_basis', 'evidence_plan', 'risks']
    csv_write(output / '候选选题.csv', fields, candidates)
    pool = ['# 候选选题', '', '排序来自 AI 对来源、受众、可执行证据和风险的解释，不是平台流量预测。']
    for c in candidates:
        pool += ['', f'## {c["priority"]}. {c["title"]}', f'观众：{c["audience"]}',
                 f'理由：{c["reason"]}', f'开头：{c["opening"]}', f'适配：{c["fit"]}',
                 f'热度依据：{text(c.get("heat_basis"))}', f'讨论依据：{text(c.get("discussion_basis"))}',
                 f'拟用证据：{text(c["evidence_plan"])}', f'问题：{text(c["risks"])}', f'来源：{text(c["source_refs"])}']
    if not candidates:
        pool += ['', '尚无选题标注；不能凭整理表自动编造推荐。']
    (output / '候选选题.md').write_text('\n'.join(pool) + '\n', encoding='utf-8')
    if analysis.get('draft'):
        (output / '视频初稿_待确认.txt').write_text(analysis['draft']['text'].strip() + '\n', encoding='utf-8')
    record = {'unique_posts': len(posts), 'duplicates_merged': duplicates, 'account_groups': len(groups),
              'annotated_posts': len(annotations), 'comment_samples': len(comments), 'candidates': len(candidates),
              'draft_written': bool(analysis.get('draft')), 'missing_metrics':
              {m: sum(p[m] is None for p in posts) for m in COUNTS},
              'scope': 'Observed input plus AI annotations; not an unattended platform scraper or viral guarantee'}
    (output / '整理记录.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    return record


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input', type=Path)
    p.add_argument('--config', required=True, type=Path)
    p.add_argument('--analysis', type=Path)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    result = build(read_json(args.input), read_json(args.config),
                   read_json(args.analysis) if args.analysis else {}, args.output)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
