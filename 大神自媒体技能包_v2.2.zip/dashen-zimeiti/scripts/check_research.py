"""Run focused regression checks; writes a fresh output folder and keeps evidence."""
import argparse
import csv
import json
from pathlib import Path

from organize_research import normalize
from research_report import build
from new_episode import create


def run(output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    checks = []

    def passed(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append(name)

    def rejected(name, action, error=ValueError):
        try:
            action()
        except error:
            checks.append(name)
        else:
            raise AssertionError(name)

    base = {'source': 'https://example.org/video/1', 'video_id': '1',
            'platform': 'A', 'account': 'same', 'title': 'Observed title',
            'captured_at': '2026-10-13T01:00:00+08:00', 'likes': 0,
            'content_scope': '标题/描述'}
    rows, duplicates = normalize([base, dict(base, description='detail', comments=2)])
    passed('same-time duplicates merge content and metrics', duplicates == 1 and rows[0]['comments'] == 2)
    rows, _ = normalize([base, dict(base, captured_at='later', comments=5, description='detail')])
    passed('different-time metrics stay separate', rows[0]['comments'] is None and rows[0]['likes'] == 0 and rows[0]['description'] == 'detail')
    for value in [-1, True, '1万', 1.5]:
        rejected('invalid count ' + repr(value), lambda value=value: normalize([dict(base, likes=value)]))
    rejected('nonfinite duration', lambda: normalize([dict(base, duration_seconds=float('nan'))]))
    rejected('comment without source', lambda: normalize([dict(base, comment_samples=[{'text': 'x'}])]))
    rejected('unknown analysis source', lambda: build({'posts': [base]}, {}, {'videos': [{'source': 'unknown'}]}, output / 'invalid'))
    rejected('title cannot become full transcript', lambda: build({'posts': [base]}, {}, {'videos': [{'source': base['source'], 'content_scope': '全文'}]}, output / 'invalid'))
    candidate = dict(id='t1', title='Original topic', audience='viewer', reason='reason',
                     opening='opening', fit='own case', risks=['risk'], evidence_plan=['own artifact'],
                     priority=1, source_refs=[base['source']])
    rejected('unknown candidate source', lambda: build({'posts': [base]}, {}, {'candidates': [dict(candidate, source_refs=['unknown'])]}, output / 'invalid'))
    rejected('draft needs selected candidate', lambda: build({'posts': [base]}, {}, {'draft': {'candidate_id': 'missing', 'text': 'draft', 'source_refs': [base['source']]}}, output / 'invalid'))
    comment = {'text': 'How?', 'source': base['source'], 'category': 'tutorial'}
    data = {'posts': [dict(base, comment_samples=[comment]),
                      dict(base, source='https://example.org/video/2', platform='B'),
                      dict(base, source='https://example.org/video/3', video_id='3', account=None),
                      dict(base, source='https://example.org/video/4', video_id='4', account=None)]}
    record = build(data, {}, {}, output / 'without-analysis')
    passed('platform and unknown authors remain separate', record['account_groups'] == 4)
    passed('unknown values and exact zero survive JSON', json.loads((output / 'without-analysis' / '视频资料库.json').read_text(encoding='utf-8'))['posts'][0]['views'] is None)
    passed('no analysis means no fabricated draft', not record['draft_written'] and record['candidates'] == 0)
    with (output / 'without-analysis' / '评论问题.csv').open(encoding='utf-8-sig', newline='') as f:
        passed('comment text survives report', list(csv.DictReader(f))[0]['text'] == 'How?')
    analysis = {'candidates': [candidate], 'draft': {'candidate_id': 't1', 'text': 'Original full draft.', 'source_refs': [base['source']]}}
    record = build({'posts': [base]}, {}, analysis, output / 'with-draft')
    passed('source-backed draft written', record['draft_written'] and (output / 'with-draft' / '视频初稿_待确认.txt').read_text(encoding='utf-8').strip() == 'Original full draft.')
    rejected('report refuses overwrite', lambda: build({'posts': [base]}, {}, {}, output / 'with-draft'), FileExistsError)
    passed('empty sample stays empty', build({'posts': []}, {}, {}, output / 'empty')['unique_posts'] == 0)
    episode = create(output / 'episode', 'Regression sample')
    passed('episode includes research configuration', (episode / '研究' / '研究配置.json').is_file())
    rejected('episode refuses overwrite', lambda: create(episode, 'changed'), FileExistsError)
    passed('episode input unchanged after rejection', json.loads((episode / '本期配置.json').read_text(encoding='utf-8'))['题目'] == 'Regression sample')
    result = {'passed': len(checks), 'checks': checks}
    (output / '回归检查.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    print(json.dumps(run(parser.parse_args().output), ensure_ascii=False))
