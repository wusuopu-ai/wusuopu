"""Normalize collected research JSON into a traceable CSV; no network access."""
import argparse
import csv
import json
import math
from pathlib import Path

FIELDS = ['source', 'video_id', 'platform', 'account', 'title', 'published_at',
          'captured_at', 'duration_seconds', 'transcript_file', 'views', 'likes',
          'comments', 'saves', 'shares', 'evidence_status', 'notes',
          'account_url', 'description', 'transcript', 'content_scope',
          'metrics_raw', 'comment_samples', 'snapshot_file']
COUNTS = ['views', 'likes', 'comments', 'saves', 'shares']


def normalize(posts):
    rows, seen, duplicates = [], {}, 0
    for index, post in enumerate(posts):
        if not isinstance(post, dict) or not post.get('source') or not post.get('title'):
            raise ValueError(f'Post {index}: source and title are required')
        source = str(post['source']).strip()
        title = str(post['title']).strip()
        if not source or not title:
            raise ValueError(f'Post {index}: source and title must not be blank')
        row = {field: post.get(field) for field in FIELDS}
        row.update(source=source, title=title)
        for field in COUNTS:
            value = row[field]
            if value is not None and (type(value) is not int or value < 0):
                raise ValueError(f'Post {index}: {field} must be a nonnegative integer or null')
        duration = row['duration_seconds']
        if duration is not None and (type(duration) not in (int, float) or not math.isfinite(duration) or duration < 0):
            raise ValueError(f'Post {index}: invalid duration_seconds')
        for field in ['metrics_raw']:
            if row[field] is not None and not isinstance(row[field], dict):
                raise ValueError(f'Post {index}: {field} must be an object')
        if row['comment_samples'] is not None:
            if not isinstance(row['comment_samples'], list):
                raise ValueError(f'Post {index}: comment_samples must be a list')
            for comment in row['comment_samples']:
                if not isinstance(comment, dict) or not comment.get('text') or not comment.get('source'):
                    raise ValueError(f'Post {index}: each comment needs text and source')
        key = (post.get('platform'), str(post['video_id'])) if post.get('video_id') else source.rstrip('/')
        if key in seen:
            duplicates += 1
            # Keep the first metric snapshot intact. Complementary metrics may
            # only be merged when both observations have the same known time.
            existing = rows[seen[key]]
            same_snapshot = bool(existing['captured_at']) and existing['captured_at'] == row['captured_at']
            for field in FIELDS:
                if field in COUNTS + ['metrics_raw', 'captured_at'] and not same_snapshot:
                    continue
                if existing[field] in (None, '', [], {}) and row[field] not in (None, '', [], {}):
                    existing[field] = row[field]
            continue
        seen[key] = len(rows)
        rows.append(row)
    return rows, duplicates


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict) or not isinstance(data.get('posts'), list):
        raise ValueError('Input must contain a posts list')
    rows, duplicates = normalize(data['posts'])
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / '视频资料表.csv').open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows({key: json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value
                         for key, value in row.items()} for row in rows)
    (args.output / '视频资料库.json').write_text(json.dumps({'posts': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    record = {'input': str(args.input.resolve()), 'unique_posts': len(rows),
              'duplicates_skipped': duplicates,
              'missing_metrics': {field: sum(row[field] is None for row in rows) for field in COUNTS},
              'scope': 'Collected input only; no platform access or viral classification'}
    (args.output / '整理记录.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    main()
